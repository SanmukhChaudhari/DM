#!/usr/bin/env python
# coding: utf-8

# In[57]:


import numpy as np
import random
from random import sample
num = np.random.randint(1,21,100);
print(num);


# In[58]:


withreplacement = [];
for i in range(5):
    withreplacement.append(random.choice(num));
print("With Replacement : ");
print(withreplacement);


# In[60]:


withoutreplacement = random.sample(set(num),5);
print("Without Replacement : ");
print(withoutreplacement);#it must not contain duplicate value


# In[ ]:





# In[ ]:





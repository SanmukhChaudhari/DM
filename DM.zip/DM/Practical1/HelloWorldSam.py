#!/usr/bin/env python
# coding: utf-8

# In[1]:


print("Hello World!");


# In[ ]:





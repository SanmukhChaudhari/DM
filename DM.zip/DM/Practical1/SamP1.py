#!/usr/bin/env python
# coding: utf-8

# In[5]:


import numpy as np
from scipy import stats
import matplotlib
import matplotlib.pyplot as plt


# In[33]:


get_ipython().run_line_magic('matplotlib', 'inline')
matplotlib.style.use('ggplot')


# In[87]:


lst = [5.2,3.2,5.7,6.9,2.8,3.5,6.7,7.8,7.3,7.2,9.5,4.5,4.2,2.8,3.2,4.9,5.9,9.2,5.7,4.5];


# In[68]:


plt.hist(lst, bins=10, range=(0,10), edgecolor='black')
plt.axis([0,10,0,5])
plt.ylabel('Occurance')
plt.xlabel('Data')
plt.show()


# In[85]:


np.mean(lst)


# In[81]:


np.median(lst)


# In[75]:


mode = stats.mode(lst)
md = mode.mode[0]
c = mode.count[0]
print("Mode is : ",md," Occurance Is : ",c)


# In[86]:


np.ptp(lst)


# In[77]:


np.var(lst)


# In[78]:


np.std(lst)


# In[62]:


stats.sem(lst)


# In[ ]:




